using System;
using System.Linq;
using System.Threading.Tasks;
using FunctionApp1.Messages;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Microsoft.WindowsAzure.Storage.Table;

namespace FunctionApp1
{
    public class LogFormLetterToStorage
    {
        [FunctionName("LogFormLetterToStorage")]
        [StorageAccount("AzureWebJobsStorage")]
        public async Task Run([QueueTrigger("outputletter", Connection = "")]FormLetter myQueueItem,
            [Table("letters", "1", "KEY", Take = 1)] UrlKey keyTable,
            [Table("letters")] CloudTable tableout,
            //[Table("letters")] IAsyncCollector<LetterEntity> letterTableCollector,
            ILogger log)
        {
            if (keyTable == null)
            {
                keyTable = new UrlKey
                {
                    PartitionKey = "1",
                    RowKey = "KEY",
                    Id = 1024
                };
                var addKey = TableOperation.Insert(keyTable);
                await tableout.ExecuteAsync(addKey);
            }

            int idx = keyTable.Id;
            const string ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            var s = string.Empty;
            while (idx > 0)
            {
                s += ALPHABET[idx % ALPHABET.Length];
                idx /= ALPHABET.Length;
            }
            var code = string.Join(string.Empty, s.Reverse());
            //TODO map FormLetter message to LetterEntity type and save to table storage
            var entityLetter = new LetterEntity
            {
                PartitionKey = $"{code[0]}",
                RowKey = code,
                Heading = myQueueItem.Heading,
                Likelihood = myQueueItem.Likelihood,
                ExpectedDate = myQueueItem.ExpectedDate,
                RequestedDate = myQueueItem.RequestedDate,
                Body = myQueueItem.Body,
                Greeting = myQueueItem.Greeting,
                From = myQueueItem.From
            };

            keyTable.Id++;
            var operation = TableOperation.Replace(keyTable);
            await tableout.ExecuteAsync(operation);
            operation = TableOperation.Insert(entityLetter);
            await tableout.ExecuteAsync(operation);
            //await letterTableCollector.AddAsync(new LetterEntity { });
            log.LogInformation($"C# Queue trigger function processed: {myQueueItem}");

        }
    }
    public class UrlKey : TableEntity
    {
        public int Id { get; set; }
    }
    public class LetterEntity : TableEntity {
        public string Heading { get; set; }
        public double Likelihood { get; set; }
        public DateTime ExpectedDate { get; set; }
        public DateTime RequestedDate { get; set; }
        public string Body { get; set; }
        public string Greeting { get; set; }
        public string From { get; set; }
    }
}
