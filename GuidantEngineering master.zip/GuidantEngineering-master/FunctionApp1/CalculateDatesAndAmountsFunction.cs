using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;
using FunctionApp1.Messages;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;

namespace FunctionApp1
{
    public class CalculateDatesAndAmountsFunction
    {
        [FunctionName("CalculateDatesAndAmountsFunction")]
        public async Task Run([QueueTrigger("messagetomom", Connection = "")]MessageToMom myQueueItem, 
            [Queue("outputletter")] IAsyncCollector<FormLetter> letterCollector,
            ILogger log)
        {
            log.LogInformation($"{myQueueItem.Greeting} {myQueueItem.HowMuch} {myQueueItem.HowSoon}");
            log.LogInformation($"C# Queue trigger function processed: {myQueueItem}");

            FormLetter frmLetter = new FormLetter();
            //TODO parse flattery list into comma separated string
            string flattery = $"Mother {string.Join(", ", myQueueItem.Flattery)}";
            //TODO populate Header with salutation comma separated string and "Mother"
            string nHeading = $"Greeting Mother";

            //TODO calculate likelihood of receiving loan based on this decision tree
            // 100 percent likelihood (initial value) minus the probability expressed from the quotient of how much and the total maximum amount ($10000)
            Random rand = new Random();
            decimal howMuch = myQueueItem.HowMuch;
            const int iterations = 10000;
            for (int i = 0; i < iterations; i++)
            {
                if (rand.Next(1, 101) <= 25)
                {
                    howMuch++;
                }
            }
            decimal likelihood = ((decimal)howMuch / iterations);
            //TODO calculate approximate actual date of loan receipt based on this decision tree
            // funds will be made available 10 business days after day of submission
            // business days are weekdays, there are no holidays that are applicable
            DateTime dtExpectedDate = BusinessDays.AddBusinessDays(DateTime.Now, 10);
            DateTime dtHowSoon = Convert.ToDateTime(myQueueItem.HowSoon);

            //TODO use new values to populate letter values per the following:
            var formLetter = new FormLetter
            {
                Body = $": Really need help: I need {myQueueItem.HowMuch} by {dtExpectedDate.ToString("dddd, dd MMMM yyyy")}",
                ExpectedDate = dtExpectedDate,
                RequestedDate = dtHowSoon,
                Heading = nHeading,
                Likelihood = (double)likelihood,
                Greeting = myQueueItem.Greeting,
                From = myQueueItem.From
            };

            //await letterCollector.AddAsync(new FormLetter { });
            await letterCollector.AddAsync(formLetter);
        }
    }
}
